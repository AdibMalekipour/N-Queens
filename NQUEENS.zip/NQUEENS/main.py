from ui.gui import NQueensApp

if __name__ == "__main__":
    NQueensApp().run()
